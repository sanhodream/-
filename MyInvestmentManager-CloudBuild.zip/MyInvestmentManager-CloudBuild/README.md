# My Investment Manager — Android MVP

## 구현 내용
- Kotlin + Jetpack Compose 기반 Android 앱
- 삼성증권 계좌 데이터를 앱에서 직접 입력/수정
- 종목 추가, 수량·평균단가·현재가 수정
- 현금 잔액 직접 수정
- 총자산, 평가손익, 자산배분 도넛 차트
- Android DataStore로 기기 내부 저장

## 초기 데이터
2026-10-30에 공유된 계좌 화면을 초기값으로 입력했습니다. 앱을 사용하기 전에 실제 잔고와 대조해 주세요.

## 아직 구현되지 않은 기능
- 삼성증권 계좌 API 연결
- 실시간 주가 및 환율 자동 수집
- 자동 분석 엔진
- 실제 푸시/가격 알림
- 매매 주문 기능

따라서 현재 버전은 **직접 입력형 자산관리 MVP**입니다. 자동 분석과 알림을 완성하려면 다음 단계에서 시세 공급자, 백엔드, 알림 스케줄러를 연결해야 합니다.

## Android Studio에서 실행
1. Android Studio 최신 안정 버전을 설치합니다.
2. 이 폴더를 Gradle 프로젝트로 엽니다.
3. Android SDK 35 설치 및 Gradle Sync를 진행합니다.
4. Android 8.0 이상 기기 또는 에뮬레이터에서 실행합니다.

패키지명: `com.example.myinvestmentmanager`
