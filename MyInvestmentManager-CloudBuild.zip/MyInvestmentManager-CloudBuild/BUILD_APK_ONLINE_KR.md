# 스마트폰 설치용 APK 만들기 (GitHub Actions)

이 프로젝트에는 GitHub의 클라우드 빌드 환경에서 APK를 생성하는 워크플로가 포함되어 있습니다.
개발 PC에 Android Studio나 Android SDK를 설치할 필요가 없습니다. 단, GitHub 계정과 저장소 업로드는 필요합니다.

## 1. GitHub 저장소 만들기
1. https://github.com 에 로그인합니다.
2. 우측 상단 `+` → `New repository`를 선택합니다.
3. 저장소 이름을 `MyInvestmentManager`로 지정하고 `Private`를 선택한 뒤 생성합니다.

## 2. 프로젝트 업로드
1. 이 ZIP을 PC에서 압축 해제합니다.
2. 압축 해제한 프로젝트 안의 파일과 `.github` 폴더를 저장소에 업로드합니다.
   - GitHub 저장소 화면에서 `Add file` → `Upload files`
   - 프로젝트 파일/폴더를 모두 선택해 업로드하고 `Commit changes`를 누릅니다.
   - `.github/workflows/android-apk.yml` 경로가 그대로 유지되어야 합니다.

## 3. 클라우드 빌드 실행
1. 저장소의 `Actions` 탭으로 이동합니다.
2. `Build Android APK` 워크플로를 선택합니다.
3. `Run workflow` → `Run workflow`를 누릅니다.
   - main 브랜치에 업로드하면 push 이벤트로 자동 빌드도 시작됩니다.
4. 실행 결과가 초록색 체크로 끝나면 해당 실행 항목을 엽니다.
5. 아래쪽 `Artifacts`에서 `MyInvestmentManager-debug-apk`를 다운로드합니다.
6. ZIP을 풀면 `app-debug.apk`가 들어 있습니다.

## 4. 갤럭시에 설치
1. `app-debug.apk`를 갤럭시로 전송합니다.
2. 파일 앱에서 APK를 누릅니다.
3. 설치가 차단되면 설정 화면에서 해당 파일 앱의 `알 수 없는 앱 설치 허용`을 켭니다.
4. 다시 APK를 눌러 설치합니다.

## 빌드 정보와 제한
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- Android compile SDK: 35
- 생성물: 서명되지 않은 디버그 APK (개인 테스트 설치용)
- 이 작업은 GitHub Actions가 실제로 실행되어야 APK가 생성됩니다. 이 대화 환경에서는 외부 네트워크/DNS 접근이 차단되어 클라우드 빌드를 대신 실행하거나 APK 생성을 검증할 수 없습니다.
- APK 설치 후 실제 기기 동작 테스트는 별도로 필요합니다.
