package com.example.myinvestmentmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

private val ComponentActivity.store by preferencesDataStore("portfolio")
private val HOLDINGS = stringPreferencesKey("holdings")
private val CASH = stringPreferencesKey("cash")
data class Holding(val name:String,val code:String,val qty:Int,val avg:Long,val price:Long) {
    val value get()=qty.toLong()*price
    val pnl get()=qty.toLong()*(price-avg)
}
private val seed=listOf(
 Holding("삼성전자","005930",22,269108,221500),
 Holding("SK하이닉스","000660",2,1726890,1419000),
 Holding("TIGER 미국S&P500","360750",68,26070,25315),
 Holding("PLUS 미국단기회사채(AAA~A)","채권",20,123785,121330),
 Holding("KODEX 금융고배당TOP10타겟위클리커버드콜","498270",100,11479,10390)
)
private val colors=listOf(Color(0xFF4F8EF7),Color(0xFF1EB891),Color(0xFFF4B942),Color(0xFF9B79E8),Color(0xFFE87585),Color(0xFF64748B))
private fun won(v:Long)=NumberFormat.getNumberInstance(Locale.KOREA).format(v)+"원"

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent { MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF83B5FF),background=Color(0xFF0B1220),surface=Color(0xFF172338))) { App(this) } }}
}
@Composable fun App(activity:MainActivity){
 var holdings by remember { mutableStateOf(seed) }
 var cash by remember { mutableLongStateOf(26459324L) }
 var cashInput by remember { mutableStateOf("26459324") }
 var editIndex by remember { mutableIntStateOf(-2) }
 var message by remember { mutableStateOf("초기값: 2026-10-30 계좌 화면. 실제 잔고와 대조 후 사용하세요.") }
 val scope= rememberCoroutineScope()
 LaunchedEffect(Unit){
  val p=activity.store.data.first()
  p[HOLDINGS]?.let { raw -> runCatching { val a=JSONArray(raw); holdings=(0 until a.length()).map { i -> val o=a.getJSONObject(i); Holding(o.getString("name"),o.getString("code"),o.getInt("qty"),o.getLong("avg"),o.getLong("price")) } } }
  p[CASH]?.toLongOrNull()?.let { cash=it; cashInput=it.toString() }
 }
 fun save(){scope.launch { activity.store.edit { p -> val a=JSONArray(); holdings.forEach { h -> a.put(JSONObject().apply { put("name",h.name);put("code",h.code);put("qty",h.qty);put("avg",h.avg);put("price",h.price) }) };p[HOLDINGS]=a.toString();p[CASH]=cash.toString() } }}
 val invested=holdings.sumOf{it.value};val total=invested+cash;val pnl=holdings.sumOf{it.pnl}
 Scaffold(containerColor=Color(0xFF0B1220)){ padding ->
  LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
   item { Text("MY INVESTMENT MANAGER",color=Color(0xFF91A8C7),fontSize=11.sp,fontWeight=FontWeight.Bold);Text("투자 대시보드",fontSize=25.sp,fontWeight=FontWeight.Bold) }
   item { Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF17263A)),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(18.dp)){Text("총 금융자산",color=Color.LightGray);Text(won(total),fontSize=27.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));Text("투자자산  ${won(invested)}");Text("출금 가능 현금  ${won(cash)}");Text("평가손익  ${won(pnl)}",color=if(pnl>=0)Color(0xFF50D5A0) else Color(0xFFFF8585))}}}
   item { Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF172338))){Column(Modifier.padding(16.dp)){Text("전체 자산 배분",fontSize=18.sp,fontWeight=FontWeight.Bold);Row(verticalAlignment=Alignment.CenterVertically){Canvas(Modifier.size(150.dp)){var start=-90f;val vals=holdings.map{it.value.toFloat()}+cash.toFloat();val sum=vals.sum().coerceAtLeast(1f);vals.forEachIndexed{i,v->val sweep=360f*v/sum;drawArc(if(i==vals.lastIndex)colors[5] else colors[i%5],start,sweep,false,style=Stroke(24.dp.toPx()),size=Size(size.width,size.height));start+=sweep}};Spacer(Modifier.width(12.dp));Column(verticalArrangement=Arrangement.spacedBy(7.dp)){holdings.forEachIndexed{i,h->Legend(colors[i%5],h.name,h.value,total)};Legend(colors[5],"현금",cash,total)}}}}
   item { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("보유 종목",fontSize=19.sp,fontWeight=FontWeight.Bold);TextButton(onClick={editIndex=-1}){Text("+ 종목 추가")}} }
   items(holdings){h->Card(Modifier.fillMaxWidth().clickable{editIndex=holdings.indexOf(h)},colors=CardDefaults.cardColors(containerColor=Color(0xFF172338))){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(h.name,fontWeight=FontWeight.Bold);Text("${h.qty}주 · 평균 ${won(h.avg)}",fontSize=12.sp,color=Color.LightGray);Text("현재가 ${won(h.price)}",fontSize=13.sp)};Column(horizontalAlignment=Alignment.End){Text(won(h.value),fontWeight=FontWeight.Bold);Text(won(h.pnl),fontSize=12.sp,color=if(h.pnl>=0)Color(0xFF50D5A0) else Color(0xFFFF8585))}}}}
   item { Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF172338))){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("현금 및 매수 알림 설정",fontSize=18.sp,fontWeight=FontWeight.Bold);OutlinedTextField(cashInput,{cashInput=it},label={Text("출금 가능 현금 (원)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true);Button(onClick={cashInput.toLongOrNull()?.let{cash=it;save();message="현금 잔액 저장 완료"}}){Text("현금 저장")};Text("매수 알림은 다음 단계에서 실시간 시세 데이터와 연결합니다.",fontSize=12.sp,color=Color.LightGray)}}}
   item { Text(message,fontSize=12.sp,color=Color(0xFF9FB0C7)) }
   item { Text("현재 MVP: 계좌 직접 입력 및 기기 내 저장. 실시간 시세·자동 알림·주문 기능은 미연동 상태입니다.",fontSize=11.sp,color=Color.Gray) }
  }
 }
 if(editIndex!=-2){
  val old=holdings.getOrNull(editIndex)
  var name by remember(editIndex){mutableStateOf(old?.name?:"")}
  var code by remember(editIndex){mutableStateOf(old?.code?:"")}
  var qty by remember(editIndex){mutableStateOf((old?.qty?:1).toString())}
  var avg by remember(editIndex){mutableStateOf((old?.avg?:0).toString())}
  var price by remember(editIndex){mutableStateOf((old?.price?:0).toString())}
  AlertDialog(onDismissRequest={editIndex=-2},title={Text(if(old==null)"종목 추가" else "종목 수정")},text={Column(verticalArrangement=Arrangement.spacedBy(5.dp)){OutlinedTextField(name,{name=it},label={Text("종목명")});OutlinedTextField(code,{code=it},label={Text("종목코드")});OutlinedTextField(qty,{qty=it},label={Text("수량")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number));OutlinedTextField(avg,{avg=it},label={Text("평균단가")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number));OutlinedTextField(price,{price=it},label={Text("현재가")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))}},confirmButton={TextButton(onClick={val q=qty.toIntOrNull();val a=avg.toLongOrNull();val p=price.toLongOrNull();if(name.isNotBlank()&&q!=null&&q>0&&a!=null&&p!=null){val h=Holding(name,code,q,a,p);holdings=if(editIndex>=0)holdings.toMutableList().also{it[editIndex]=h}else holdings+h;save();message="종목 정보를 저장했습니다.";editIndex=-2}}){Text("저장")}},dismissButton={TextButton(onClick={editIndex=-2}){Text("취소")}})
 }
}
@Composable private fun Legend(c:Color,label:String,value:Long,total:Long){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(8.dp).background(c,CircleShape));Spacer(Modifier.width(5.dp));Text(label,fontSize=10.sp,maxLines=1,modifier=Modifier.widthIn(max=145.dp));Spacer(Modifier.width(4.dp));Text("${if(total>0)value*100/total else 0}%",fontSize=10.sp,fontWeight=FontWeight.Bold)}}
